class Employee:
    name="priyanshu"
    language="python"

    def getinfo(self):
        print(f"The language is {self.language} and name {self.name} ")
    @staticmethod
    def greet():
        print("good Morning")

var1=Employee()
var1.getinfo()
var1.greet()
# print(var1.name,var1.language)
