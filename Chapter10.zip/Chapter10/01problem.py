#Creating a class "programmer" for storing information of few programmer working at microsoft

class Programmer:
    company="microsoft"
    def __init__(self,name,salary, pin):
        self.name=name
        self.salary=salary
        self.pin=pin
p = Programmer("Priyanshu",1200000,234567)
print(p.name, p.salary, p.pin)
r = Programmer("Pisav",1200000,234567)
print(r.name, r.salary, r.pin)