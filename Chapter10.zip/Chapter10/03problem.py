#create a class with a class attibute a: create an object from it 
#and set 'a' directly using object.a=o. Does this change the class attribute

class Demo:
    a=4
o=Demo()
o.a=0

print(o.a)