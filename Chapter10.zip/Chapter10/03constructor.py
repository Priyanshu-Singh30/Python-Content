class Employee:
    name="priyanshu"
    language="python"

    def __init__(self):  #dunder method which is automatically called
        print("I am creating an object")

    def getinfo(self):
        print(f"The language is {self.language} and name {self.name} ")
    @staticmethod
    def greet():
        print("good Morning")

var1=Employee()
var1.salary=2000000
print(var1.name,var1.salary)
