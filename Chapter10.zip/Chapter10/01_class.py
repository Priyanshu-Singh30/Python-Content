class Employee:
    name="priyanshu"
    language="python"

var1=Employee()
print(var1.name,var1.language)
