#Can you change the self-parameter inside a class to somethingnelse(say "Priyanshu")
#.try changing self to "slf or "Priyanshu" and see the effect
from random import randint
class Train:
    def __init__(slf, trainNo):
        slf.trainNo=trainNo
    def book(slf, fro, to):
        print(f"ticket is booked in train number:{slf.trainNo} from {fro} to {to}")

    def getStatus(slf):
        print(f"Train Number:{slf.trainNo} is running successfully")

    def getFare(slf, fro, to):
        print(f"ticket is fare in train number:{slf.trainNo} from {fro} to {to} is {randint(22,5555)}")

t=Train(1299)
t.book("Rampur","Delhi")
t.getStatus()
t.getFare("Rampur","Delhi")
